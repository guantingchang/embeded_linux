#define DTC_VERSION "DTC 1.4.6-gaadd0b65"
