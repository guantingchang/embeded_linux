.. SPDX-License-Identifier: GPL-2.0+

Unified Extensible Firmware (UEFI)
==================================

.. toctree::
   :maxdepth: 2

   uefi.rst
   u-boot_on_efi.rst
   iscsi.rst
