.. SPDX-License-Identifier: GPL-2.0+

Architecture-specific doc
=========================

.. toctree::
   :maxdepth: 2

   arc
   arm64
   m68k
   mips
   nds32
   nios2
   sandbox
   sh
   x86
   xtensa
