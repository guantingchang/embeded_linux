.. SPDX-License-Identifier: GPL-2.0+

Board-specific doc
==================

.. toctree::
   :maxdepth: 2

   AndesTech/index
   atmel/index
   coreboot/index
   emulation/index
   freescale/index
   google/index
   intel/index
   renesas/index
   sifive/index
   xilinx/index
