.. SPDX-License-Identifier: GPL-2.0+

Coreboot
========

.. toctree::
   :maxdepth: 2

   coreboot
