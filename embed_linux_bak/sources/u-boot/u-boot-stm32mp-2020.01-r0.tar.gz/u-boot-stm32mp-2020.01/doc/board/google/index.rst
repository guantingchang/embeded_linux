.. SPDX-License-Identifier: GPL-2.0+

Google
======

.. toctree::
   :maxdepth: 2

   chromebook_link
   chromebook_samus
