.. SPDX-License-Identifier: GPL-2.0+

Intel
=====

.. toctree::
   :maxdepth: 2

   bayleybay
   cherryhill
   cougarcanyon2
   crownbay
   edison
   galileo
   minnowmax
   slimbootloader
