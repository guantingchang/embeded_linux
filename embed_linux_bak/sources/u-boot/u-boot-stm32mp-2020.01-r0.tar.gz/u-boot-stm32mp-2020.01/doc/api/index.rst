.. SPDX-License-Identifier: GPL-2.0+

U-Boot API documentation
========================

.. toctree::
   :maxdepth: 2

   efi
   linker_lists
   serial
